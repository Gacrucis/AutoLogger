lessons = {}

lessons['LUNES'] = {
    14 : {'id' : '97509006122', 'password' : '155078'},
    16 : {'id' : '96111704699', 'password' : '484597'},

    }

lessons['MARTES'] = {
    14 : {'id' : '94760158203', 'password' : '140731'},
    }

lessons['MIERCOLES'] = {
    16 : {'id' : '93129044428', 'password' : '126577'}
    }

lessons['JUEVES'] = {
    7 : {'id' : '94333000043', 'password' : '55755'},
    14 : {'id' : '98761023239', 'password' : '105911'},
    16 : {'id' : '98453867343', 'password' : '455156'},
    }

lessons['VIERNES'] = {
    10 : {'id' : '95920136763', 'password' : '929402'},
    14 : {'id' : '98205652142', 'password' : '19704'},
    16 : {'id' : '91234573656', 'password' : '326177'}
    }

# lessons['SABADO'] = {
#     7 : {'id' : '93392589663', 'password' : '126432'}
#     }